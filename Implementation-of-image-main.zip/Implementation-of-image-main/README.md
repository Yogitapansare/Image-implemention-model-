Required Libraries:

You need to install the following Python libraries:

--------------------------------------------------------------------------------------------------------------------
TensorFlow (to load and use the MobileNetV2 model)

Keras (for image processing and model inference)

PIL (Pillow) (for handling images)

Matplotlib (for creating and displaying the prediction bar chart)

Tkinter (for creating the GUI)

--------------------------------------------------------------------------------------------------------------------
install the liberies 

---------------------------------------------------------------------------------------------------------------------
pip install tensorflow

pip install pillow

pip install matplotlib

pip install tk

---------------------------------------------------------------------------------------------------------------------
